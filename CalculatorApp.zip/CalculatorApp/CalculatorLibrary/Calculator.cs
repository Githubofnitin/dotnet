﻿namespace CalculatorLibrary;

public class Class1
{

}
